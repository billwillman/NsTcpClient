﻿using UnityEngine;
using NsLib.Utils;

namespace NsLib
{
    class NsLibMono: MonoBehaviour
    {
        private static NsLibMono m_Instance = null;
        private static bool m_IsAppQuit = false;

        void OnApplicationQuit()
        {
            m_IsAppQuit = true;
        }

        void Awake()
        {
            m_Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }

        void Update()
        {
            var timeMgr = TimerMgr.GetInstance();
            if (timeMgr != null)
            {
                timeMgr.ScaleTick(Time.deltaTime);
                timeMgr.UnScaleTick(Time.unscaledDeltaTime);
            }
        }

        public static NsLibMono Instance
        {
            get
            {
                if (m_IsAppQuit)
                    return null;
                if (m_Instance == null)
                {
                    GameObject obj = new GameObject("NsLib", typeof(NsLibMono));
                    m_Instance = obj.GetComponent<NsLibMono>();
                }
                return m_Instance;
            }
        }

        public static NsLibMono GetInstance()
        {
            return Instance;
        }

        void OnDestroy()
        {
            m_Instance = null;
        }
    }
}
